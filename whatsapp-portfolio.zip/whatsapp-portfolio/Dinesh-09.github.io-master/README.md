# Attractive Advance Portfolio Website
## _Chatting Bot Like Design (Whatsapp like interface)_


- [Running Site](https://github.com/Danedie04/)

[![N|Solid](images/demo.gif)](https://github.com/Danedie04/)

## Technologies Used

- HTML
- Javascript
- CSS

## Features

- Whatsapp like interface
- Pleasant sounds
- Lightweighted
- Social media links
- Download resume.
- Map support for address
- Random replies for hi, bye, i love you.

<br><br>

## Connect with Me: 

<br>

[![N|Solid](images/telegram.svg)](https://github.com/Danedie04)


[![N|Solid](images/instagram.svg)](https://github.com/Danedie04)


<br>

**Free Software, Hell Yeah!**
